package com.example

val numbers = listOf(1, 2, 3)
val mnumbers = mutableListOf(1, 2, 3)
val people = mapOf(Pair("John", 42), "Jill" to 24)
val mpeople = mutableMapOf(Pair("John", 42), "Jill" to 24)

open class Shape
class Rectangle : Shape()

fun main(args: Array<String>) {
    mnumbers.add(4)
    mpeople["Bob"] = 20
    println(mpeople["Bob"])

    val jillsAge = people["Jill"]

    val rectangles = listOf(Rectangle())
    val shapes: List<Shape> = rectangles

    val mrectangles = mutableListOf(Rectangle())
    //val mshapes: MutableList<Shape> = mrectangles
}
