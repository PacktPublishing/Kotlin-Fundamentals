package com.example.pkg1

class Greeter {
	fun hello(): String = "Hello from pkg1"
}