package com.example.pkg2

class Greeter {
	fun hello(): String = "Hello from pkg2"
}