interface Greeter {
	fun hello(name: String): String
}

abstract class Person(val name: String): Greeter {
	abstract val age: Int
	override fun hello(name: String) = "Hello, $name, I'm ${this.name}"
	abstract fun goodbye(): String
}

class Customer(val id: Int, name: String, override var age: Int): Person(name) {
	override fun goodbye() = "Bye"
}

fun main(args: Array<String>) {
	val c1 = Customer(1, "John", 42)
}