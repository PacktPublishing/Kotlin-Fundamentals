class Person(val name: String, var age: Int) {
    fun nextAge(): Int {
        return age + 1
    }

    fun isOlderThan(other: Person): Boolean {
        return other.age < age
    }

    override fun equals(other: Any?): Boolean {
        return (other is Person && other.name == name)
    }
    
    override fun toString(): String {
        return "$name is $age years old"
    }
}

fun main(args: Array<String>) {
    val person1 = Person("John Doe", 42)
    val person2 = Person("Baby Doe", 2)
    person1.age = 43
    val nextAge = (person1.age ?: 0) + 1
    println(person1.nextAge())
    println(person1.isOlderThan(person2))
    println(person1 == person2)
}
