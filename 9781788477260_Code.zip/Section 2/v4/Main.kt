package com.example

import java.util.*

data class Customer(val id: UUID, val name: String, val discount: Double)

object CustomerService {
    fun create(name: String, id: UUID = UUID.randomUUID() , discount: Double = 0.0): Customer {
        return Customer(id, name, discount)
    }
}

fun main(args: Array<String>) {
    val c1 = CustomerService.create("John")
    val c2 = CustomerService.create(discount = 50.0, name = "Jill", id = 42, id = UUID(1, 1))
    println(c1)
    println(c2)
}