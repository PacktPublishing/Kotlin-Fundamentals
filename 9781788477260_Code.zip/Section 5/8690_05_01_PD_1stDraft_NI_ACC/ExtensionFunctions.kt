package com.example

import javafx.application.Application
import javafx.scene.Node
import javafx.scene.Scene
import javafx.scene.control.Button
import javafx.scene.control.Label
import javafx.scene.layout.HBox
import javafx.scene.layout.Pane
import javafx.stage.Stage

class MyApp : Application() {
    override fun start(primaryStage: Stage) {
        val root = HBox().apply {

            label("Hello Kotlin")

            button("Click me").setOnAction {
                println("You clicked me!")
            }

        }

        with(primaryStage) {
            scene = Scene(root)
            show()
        }
    }
}

fun Pane.label(text: String): Pane = add(Label(text))

fun Pane.button(text: String) = Button(text).apply {
    this@button.add(this)
}

fun Pane.add(node: Node): Pane {
    children.add(node)
    return this
}

fun main(args: Array<String>) {
    Application.launch(MyApp::class.java)
}