package com.example

data class Customer(val name: String)

interface CustomerEventListener {
    fun customerSaved(customer: Customer)
    fun customerDeleted(customer: Customer)
}
a
class CustomerService {
    companion object {
        private val listeners = mutableListOf<CustomerEventListener>()
        fun addListener(listener: CustomerEventListener) {
            listeners.add(listener)
        }
    }
    fun save(customer: Customer) {
        listeners.forEach { listener -> listener.customerSaved(customer) }
    }
    fun delete(customer: Customer) {
        listeners.forEach { listener -> listener.customerDeleted(customer) }
    }
}

fun main(args: Array<String>) {
    val service = CustomerService()
    CustomerService.addListener(object : CustomerEventListener {
        override fun customerSaved(customer: Customer) {
            println("$customer saved")
        }

        override fun customerDeleted(customer: Customer) {
            println("$customer deleted")
        }
    })
    service.save(Customer("John"))
}
