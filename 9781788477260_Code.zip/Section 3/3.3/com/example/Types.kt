package com.example

val x: Any? = "Hello World"

class Obj {
    var x: Any? = "Hello World"
}

fun main(args: Array<String>) {
    if (x is String) {
        println("x is a string of ${x.length} chars")
    }

    if (x !is String) {
        println("Not a string")
    } else {
        println(x.length)
    }

    val a = x as String
    val b = x as? String
    val c = x as? String ?: return

    println("c is a string!")
    
    val o = Obj()
    (o.x as? String)?.apply {
        println(length)
    }
}