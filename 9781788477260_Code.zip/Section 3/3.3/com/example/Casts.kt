package com.example

val x: Any? = "Hello World"

class Obj {
    var x: Any? = "Hello World"
}

fun main(args: Array<String>) {
    if (x is String) {
        println(x.length)
    }

    if (x !is String) {
        println("Not a String")
    } else {
        println(x.length)
    }

    val a = x as String
    val b = x as? String
    val c = x as? String ?: return

    println(c.length)

    val o = Obj()
    (o.x as? String)?.apply {
        println(length)
    }

    when (x) {
        is String -> println(x.length)
        "Hello World" -> println("We know this String!")
        is Int -> println(x + 1)
    }
}