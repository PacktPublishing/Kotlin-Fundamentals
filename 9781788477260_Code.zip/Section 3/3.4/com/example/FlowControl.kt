package com.example

import javafx.scene.paint.Color
import java.net.InetAddress
import java.net.UnknownHostException

data class Person(val name: String, val age: Int)

fun main(args: Array<String>) {
    val p1 = Person("John", 42)
    val p2 = Person("Jill", 24)

    val oldest: Person = if (p1.age > p2.age) {
        println(p1)
        p1
    } else {
        println(p2)
        p2
    }

}

fun isValidIP(host: String) = try {
    InetAddress.getByName(host)
    true
} catch (ex: UnknownHostException) {
    false
}

fun getColor(person: Person): Color = when (person.age) {
    1, 2 -> Color.YELLOW
    18 -> Color.RED
    in 30..50 -> Color.BISQUE
    else -> {
        println(person)
        Color.BLUE
    }
}
